﻿namespace StockSuite.Models
{
    public class UserDetails
    {
    }
}
