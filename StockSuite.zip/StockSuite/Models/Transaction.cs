﻿namespace StockSuite.Models
{
    public class Transaction
    {
    }
}
