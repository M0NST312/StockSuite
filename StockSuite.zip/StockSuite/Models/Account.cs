﻿namespace StockSuite.Models
{
    public class Account
    {
    }
}
