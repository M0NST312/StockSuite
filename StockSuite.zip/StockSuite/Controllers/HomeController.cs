﻿using Microsoft.AspNetCore.Mvc;
using StockSuite.Models;
using System.Diagnostics;
using StockSuite.MomoAPI;
using Microsoft.AspNetCore.Authorization;

namespace StockSuite.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            //CreateUser resp = new CreateUser();
            //CreateAPIUser us = new CreateAPIUser();
            //us.CreateUser();
            //resp.MakeRequest();
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}